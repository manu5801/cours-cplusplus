#include <iostream> 
#include <iterator> 
#include <vector> 


using namespace std;
 
int main() 
{ 
    // Creation du vecteur v1 = {1,2,3,4,5}
	...    
    
    // Affichage élement par élement de v1
    ...
    
    // Affichage en sens inverse
    ...
    

    
    // Recherche de la valeur val dans v1
	int val=4;
    vector<int>::iterator ...
    
    first = ...
    last = ...
 
    while (...)  
        ++first; 
     
     
    if (first != v1.end()) 
    { 
        std::cout << "Element " << val <<" trouve a la position : " ; 
        std:: cout << ... << "\n" ; 
    } 
    else
        std::cout << "Element non trouve.\n\n";    

   
    
    
    
    return 0; 
} 

