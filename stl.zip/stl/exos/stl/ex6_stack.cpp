#include <iostream>
#include <stack>

using namespace std;

int main()
{
	stack<int> pile;
	
	// Insertion de 4,2 et 1 dans la pile
	...
	
	// Taille de la pile
	...
	
	// Affichage et suppression des elements de la pile
	...
	
	// Taille de la pile
	...
	
	return 0;
}
