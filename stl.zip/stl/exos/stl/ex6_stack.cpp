#include <iostream>
#include <stack>

using namespace std;

int main()
{
	stack<int> pile;
	
	// Insertion de 4,2 et 1 dans la pile
	...
	
	// Taille de la pile
	cout << "Taille de la pile : " << ... << endl;
	
	// Affichage et suppression des elements de la pile
	while (...)
	{
		cout << ... << endl;
		...
	}
	
	// Taille de la pile
	cout << "Taille de la pile : " << ... << endl;
	
	return 0;
}
