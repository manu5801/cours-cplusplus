#include <iostream>
#include <queue>

using namespace std;

int main()
{
	queue<int> file;
	
	// Ajout de 1,4 et 2
	...
	
	// Taille de la file
	...

	// Affichage de l'element le plus ancien et Depiler
	...
	
	// Taille de la file
	...
	
	return 0;
}
