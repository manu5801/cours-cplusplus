#include "homo.hpp"

float homo::... {return facteur*x;}
