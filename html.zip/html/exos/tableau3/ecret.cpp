#include "ecret.hpp"

float ecret::... {return (x > seuil) ? seuil : x;}
