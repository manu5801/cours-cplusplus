
#ifndef __ECRET__
#define __ECRET__

#include "tableau.hpp"

// Un objet-fonction qui ecrete le tableau, derive de ofct_1p
class ecret: ...  {
public:
	ecret(float s) : seuil(s) {};
	...;
private:
	float seuil;
};

#endif
