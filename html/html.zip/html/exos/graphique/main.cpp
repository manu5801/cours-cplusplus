
#include "shape.hpp"
#include "shape.hpp"
#include "shape.hpp"

#include "closeshape.hpp"
#include "openshape.hpp"
#include <vector>

#define SQUARE   1
#define TRIANGLE 2
#define CIRCLE   3

int main() {
	vector<Shape*> shapes;
	
	Point c1(100.0f,100.0f);
	
	shapes.push_back(new Circle(c1,50.0,2,0));
	shapes.push_back(new Square(c1,50.0,2,0));
	Triangle* t = new Triangle(c1,50.0,2,0);
	t->translate(100.0,10.0).zoom(3);
	shapes.push_back(t);
	shapes.push_back(new Line(Point(100,200),Point(150,300),4,0));
	
	Path* pth = new Path(Point(200,300),4,0);
	pth->addPoint(Point(300,300));
	pth->addPoint(Point(300,400));
	pth->addPoint(Point(350,450));
	shapes.push_back(pth);
		
	shapeInit();
	for (auto s : shapes) {
		s->draw();
	}
	shapeFinish();
	for (auto s : shapes) {
		delete s;
		s = nullptr;
	}
}



