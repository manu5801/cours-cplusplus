
#pragma once

#include "shape.hpp"
#include "point.hpp"

#define PI 3.14158
#define DEMIPI   3.14158 / 2;
#define DOUBLEPI 3.14158 * 2;

class CloseShape: public Shape {
	public:
		CloseShape(Point c, float r, int dw, int dc): Shape(dw,dc),center(c),radius(r) {};
		float getRadius()  const { return radius; };
		Point getCenter() const { return center; };
		virtual CloseShape& translate(float dx, float dy) { center.x += dx; center.y += dy; return *this;};	
		virtual CloseShape& zoom(float alpha) { radius *= alpha; return *this; };	
	protected:
		Point angle2Point(float);
		
	private:
		Point center;
		float radius;
};

class Circle: public CloseShape {
	public:
		Circle(Point c, float r, int dw, int dc): CloseShape(c,r,dw,dc) {};
		virtual void draw();
};

class Square: public CloseShape {
	public:
		Square(Point c, float r, int dw, int dc): CloseShape(c,r,dw,dc) {};
		virtual void draw();
};

class Triangle: public CloseShape {
	public:
		Triangle(Point c, float r, int dw, int dc): CloseShape(c,r,dw,dc) {};
		virtual void draw();
};

