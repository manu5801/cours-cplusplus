
#pragma once

struct Point {
	Point (float X=0, float Y=0):x(X),y(Y) {};
	float x;
	float y;
};


