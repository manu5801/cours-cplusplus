
#include <cmath>
#include <iostream>
#include "closeshape.hpp"
using namespace std;


Point CloseShape::angle2Point(float a) {
	Point p;
	p.x = center.x + radius * cosf(a);
	p.y = center.y - radius * sinf(a);
	return p;
}
	
void Circle::draw() {
	cout << "<circle r=\"" << getRadius() << "\" cx=\"" << getCenter().x << "\" cy=\"" << getCenter().y << "\" stroke-width=\"" << getStrokeWidth() << "\" stroke=\"" << getStrokeColor() << "\" fill=\"none\" />\n";
}

void Square::draw() {
	Point p1,p2,p3,p4;
	p1=angle2Point( PI / 4.0f );
	p2=angle2Point( 0.75 * PI );
	float side = fabs(p1.x - p2.x);
	cout << "<rect x=\"" << p2.x << "\" y=\"" << p2.y << "\" width=\"" << side << "\" height=\"" << side << "\" stroke-width=\"" << getStrokeWidth() << "\" stroke=\"" << getStrokeColor() << "\" fill=\"none\" />\n";
}

void Triangle::draw() {
	Point p1,p2,p3;
	p1=angle2Point( 0.0f );
	p2=angle2Point( -2.0 * PI / 3.0f);
	p3=angle2Point( +2.0 * PI / 3.0f);
	
	cout << "<polygon points=\"" << p1.x << "," << p1.y << " ";
	cout << p2.x << "," << p2.y << " ";
	cout << p3.x << "," << p3.y << "\" stroke-width=\"" << getStrokeWidth() << "\" stroke=\"" << getStrokeColor() << "\" fill=\"none\" />\n";
}
