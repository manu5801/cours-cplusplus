
#include "openshape.hpp"
#include <iostream>
using namespace std;

OpenShape& OpenShape::translate(float dx, float dy) {
	vector<Point>& vp = getPoints();
	for (auto p=vp.begin(); p!= vp.end(); ++p) {
		Point& pt = *p;
		pt.x += dx;
		pt.y += dy;
	}
	return *this;
}

Line::Line(const Point& p1, const Point& p2, int dw, int dc): OpenShape(p1,dw,dc) {
	vector<Point>& vp = getPoints();
	vp.push_back(p2);
}

void Line::draw() {
	Point p1=getPoints()[0];
	Point p2=getPoints()[1];
	cout << "<line x1=\"" << p1.x << "\" y1=\"" << p1.y << "\" x2=\"" << p2.x << "\" y2=\"" << p2.y << "\" stroke-width=\"" << getStrokeWidth() << "\" stroke=\"" << getStrokeColor() << "\" fill=\"none\" />\n";
}

Path::Path(const Point& p, int dw, int dc): OpenShape(p,dw,dc) {};

Path& Path::addPoint(const Point& p) {
	vector<Point>& vp = getPoints();
	vp.push_back(p);
	return *this;
}

void Path::draw() {
	const vector<Point>& vp = getPoints();
	if (vp.size() < 2) return;
	
	for (size_t i=0; i < vp.size() - 1; ++i) {
		Point p1 = vp[i];
		Point p2 = vp[i+1];
		cout << "<line x1=\"" << p1.x << "\" y1=\"" << p1.y << "\" x2=\"" << p2.x << "\" y2=\"" << p2.y << "\" stroke-width=\"" << getStrokeWidth() << "\" stroke=\"" << getStrokeColor() << "\" fill=\"none\" />\n";
	}
}


					
