
#include "shape.hpp"
#include "shape.hpp"
#include "shape.hpp"

#include "closeshape.hpp"
#include "openshape.hpp"
#include <vector>

#define SQUARE   1
#define TRIANGLE 2
#define CIRCLE   3

int main() {
	vector<Shape> shapes;
	
	point c1(10.0,10.0);
	shapes.push_back(new Circle(c1,5.0,2,0);
	
	for (auto s : shapes) {
		s.draw();
	}
}



