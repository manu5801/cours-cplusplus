
#pragma once

#include <vector>
#include "shape.hpp"
#include "point.hpp"

using namespace std;

class OpenShape: public Shape {
	public:
		OpenShape(const Point& p, int dw, int dc): Shape(dw,dc) {
			points.push_back(p);
		}
		virtual OpenShape& translate(float, float);
		Point getStart() const { return points[0]; };
		Point getEnd() const { return points.back(); };
		
	protected:
		const vector<Point>& getPoints() const { return points; };
		vector<Point>& getPoints() { return points; };
		
	private:
		vector<Point> points;
};

class Line: public OpenShape {
	public:
		Line(const Point& p1, const Point& p2, int dw, int dc);
		virtual void draw();
};

class Path: public OpenShape {
	public:
		Path(const Point& p, int dw, int dc);
		Path& addPoint(const Point& p);
		virtual void draw();
};
