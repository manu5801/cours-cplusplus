
#include <iostream>
#include "closeshape.hpp"
using namespace std;

void shapeInit(int width, int height) {
	cout << "<svg width=\"" << width << "\" height=\"" << height << "\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:svg=\"http://www.w3.org/2000/svg\" >\n";
}

void shapeFinish() {
	cout << "</svg>\n";
}

