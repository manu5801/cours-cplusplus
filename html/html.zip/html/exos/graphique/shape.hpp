#ifndef _SHAPE_H_
#define _SHAPE_H_

#include <string>
#include <iostream>
using namespace std;

void shapeInit(int width=640, int height=480);
void shapeFinish();
	
class Shape {
	public:
		Shape(int dw, int dc) {
			stroke_width = dw;
			stroke_color = dc;
		};
		virtual void draw()                        = 0;
		virtual Shape& translate(float dx, float dy) = 0;
		int getStrokeWidth() const { return stroke_width; };
		string getStrokeColor() const { return "#000000"; };
		virtual ~Shape() {};
	private:
		int stroke_width;
		int stroke_color;
};

#endif
