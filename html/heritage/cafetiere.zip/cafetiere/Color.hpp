

#pragma once



#include <string>
using namespace std;

enum class Color { normal, red, green, bold };


string setColor(Color c);

