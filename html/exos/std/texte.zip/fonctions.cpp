#include "fonctions.hpp"

void Fonction::_litTexte() {
	string w;
	while ( true ) {
		_is >> w;
		if ( _is )
			_texte.push_back(w);
		else
			break;
	}
}

