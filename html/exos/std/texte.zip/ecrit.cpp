
#include <iterator>
#include <algorithm>
#include "ecrit.hpp"

void Ecrit::operator()() {
	_litTexte();
	if ( _p.getAlenvers() )
	{
		reverse( _texte.begin(), _texte.end() );
	}
	
	//Inserer les espaces entre les mots et le \n a la fin
	string espace = " ";
	string eol="\n";

	if ( _texte.size() > 1 )
	{
		list<string>::iterator i = _texte.begin();
		// en c++11 on ecrira:
		// auto i = _texte.begin();
		for (++i; i != _texte.end(); ++i) {
			_texte.insert ( i, espace );
		}
	}
	_texte.insert ( _texte.end(), eol );
	

	// Imprimer le texte  
	// Utilisation de l'operateur <<
/*
	for ( auto i = _texte.begin(); i != _texte.end(); ++i ) {
		_os << *i;
	}
*/
	
	// Utilisation d'un ostream_iterator
/*
	ostream_iterator<string> o (_os);
	for ( auto i = _texte.begin(); i != _texte.end(); ++i ) {
		*o = *i;
	}
*/
	// Utilisation de l'algorithme copy
	ostream_iterator<string> o (_os);
	copy ( _texte.begin(), _texte.end(), o );

}

