#ifndef __HELP_HPP__
#define __HELP_HPP__

#include <iostream>
#include "params.hpp"
#include "fonctions.hpp"

class Help: public Fonction {
public:
	Help(const Params&p, istream& is, ostream& os):Fonction(p,is,os){};
	virtual void operator()();
};

#endif
