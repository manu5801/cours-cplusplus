#ifndef __PARAMS_HPP__
#define __PARAMS_HPP__

#include <string>
using namespace std;

enum fonction_t { STATS=1, ECRIT, HELP };
enum switch_t { CENTRE=1, JUSTIFIE, ALENVERS, MOTSALENVERS };

class Params {
public:
	Params(int argc, char* argv[]);
	fonction_t getFonction() const { return __fonction; };
	string getExeNom() const { return __exe_nom; };
	bool getJustifie() const { return __justifie; };
	bool getAlenvers() const { return __alenvers; };
	bool getCentre()   const { return __centre; };

private:
	string __exe_nom;
	fonction_t __fonction;
	bool __justifie;
	bool __alenvers;
	bool __centre;
};

#endif
