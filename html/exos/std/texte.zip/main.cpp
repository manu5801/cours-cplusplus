

#include <stdexcept>
#include <iostream>

#include "params.hpp"
#include "fonctions.hpp"
#include "help.hpp"
#include "ecrit.hpp"
#include "stats.hpp"

using namespace std;

Fonction* construitFonction(const Params&, istream& is, ostream& os );

int main(int argc, char* argv[]) {
	try {
		Params p(argc,argv);
		Fonction* f_ptr = construitFonction(p,cin,cout);
		Fonction& f = *f_ptr;
		f();
	}
	catch (exception& e) {
		cerr << "Houps ! " << e.what() << "\nPROGRAMME INTERROMPU\n";
	}
}
 
 
Fonction* construitFonction (const Params& p, istream& is, ostream& os) {
	fonction_t f_num = p.getFonction();
	Fonction* f_ptr = NULL;
	//cerr << f_num << '\n';
	switch (f_num) {
		case HELP:  f_ptr = new Help(p,is,os); break;
		case ECRIT: f_ptr = new Ecrit(p,is,os); break;
		case STATS: f_ptr = new Stats(p,is,os); break;
		default: throw (logic_error("ERREUR - PAS ENCORE IMPLEMENTE") );
	}
	return f_ptr;
}
