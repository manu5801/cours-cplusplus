
#include <iterator>
#include <algorithm>
#include "stats.hpp"

/*
size_t nb_lettres = 0;
void compteur( const string& s) { nb_lettres += s.size(); };
*/

void Stats::operator()() {
	_litTexte();
	
	// Compter le nombre de mots
	size_t nb_mots = _texte.size();
	
	// Compter le nombre de lettres (en mode pieton de 2011)
	/*
	size_t nb_lettres = 0;
	for ( auto i=_texte.begin(); i!=_texte.end(); ++i) {
		nb_lettres += i->size();
	}
	*/
	
	
	// Compter le nombre de lettres (en c++98, utilisation d'une fonction et d'une variable globale)
	/* for_each( _texte.begin(), _texte.end(), compteur ); */

	// Compter le nombre de lettres (en c++11) en utilisant une fonction lambda
	// C'est bien plus elegant comme ça
	size_t nb_lettres = 0;
	for_each( _texte.begin(), _texte.end(), [&nb_lettres](const string& mot) { nb_lettres += mot.length(); } );
	
	
	auto imax = max_element( _texte.begin(), _texte.end(), [](const string& a, const string& b) { return a.size() < b.size(); } );
	auto imax1 = max_element( _texte.begin(), _texte.end() );
	auto imin  = min_element( _texte.begin(), _texte.end() );

	// Afficher les stats sur _os
	cout << "STATISTIQUES\n";
	cout << "nombre de mots    = " << nb_mots << '\n';
	cout << "nombre de lettres = " << nb_lettres << '\n';
	cout << "mot le plus long  = " << *imax << '\n';
	cout << "dernier mot dans le dictionnaire = " << *imax1 << '\n';
	cout << "premier mot dans le dictionnaire = " << *imin  << '\n';

}
