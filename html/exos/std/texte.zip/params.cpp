
#include <string>
#include <map>
#include <stdexcept>
#include "params.hpp"
#include <utility>
using namespace std;

/* ATTENTION Seulement correct en c++0x ne passe pas avec clang++ */
map<string,fonction_t> f_legales;
map<string,bool*> s_legaux;
/*map<string,fonction_t> f_legales {
	{"stats",STATS},
	{"ecrit",ECRIT},
	{"centre",CENTRE},
	{"help",HELP}
};*/


Params::Params ( int argc, char* argv[] ): __justifie(false), __alenvers(false), __centre(false) {
	
	/* En c++98 on doit initialiser dans une fonction ! */
	f_legales["stats"]    = STATS;
	f_legales["ecrit"]    = ECRIT;
	f_legales["help"]     = HELP;

	s_legaux["justifie"] = &__justifie;
	s_legaux["centre"]   = &__centre;
	s_legaux["alenvers"] = &__alenvers;

	if (argc==1) {
		throw (runtime_error ( "ERREUR - Pas de parametres specifies" ) );
	}

	string f = argv[1];
	if ( f_legales.find(f) == f_legales.end() ) {
		throw runtime_error ( "ERREUR - La fonction " + f + " est inconnue" );
	}
	__fonction = f_legales[f];
	
	for ( int i=2; i<argc;++i ) {
		string s = argv[i];
		if ( s_legaux.find(s) == s_legaux.end() ) {
			throw runtime_error ( "ERREUR - Le switch " + s + " est inconnu" );
		}
		else
		{
			*s_legaux[s] = true;
		}
	}
	__exe_nom = argv[0];
}
