#ifndef __FONCTIONS_HPP__
#define __FONCTIONS_HPP__

#include <iostream>
#include <list>
#include "params.hpp"
using namespace std;

class Fonction {
public:
	Fonction(const Params& p, istream& is, ostream& os):_p(p),_is(is),_os(os) {};
	virtual void operator()() = 0;

protected:
	const Params& _p;
	istream& _is;
	ostream& _os;
	void _litTexte();
	list<string> _texte;
};

#endif
