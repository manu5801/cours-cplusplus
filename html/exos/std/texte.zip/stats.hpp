#ifndef __STATS_HPP__
#define __STATS_HPP__

#include <iostream>
#include "params.hpp"
#include "fonctions.hpp"

class Stats: public Fonction {
public:
	Stats(const Params&p, istream& is, ostream& os):Fonction(p,is,os){};
	virtual void operator()();
};

#endif
