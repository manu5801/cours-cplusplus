

#include "help.hpp"

void Help::operator()() {
	_os << "Usage: " << _p.getExeNom() << " " << "stats|ecrit|help alenvers|centre|justifie ..." << "\n";
}
