#include "homo.hpp"

float homo::operator()(float x) const {return facteur*x;}
